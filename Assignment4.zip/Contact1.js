$(document).ready(function(){
  $("#contact").on(){
    $("#name_field").click: function(){
      $("#tip").animate("Enter your name in this box.");
  },
     $("#name_field").click: function(){
       $("h3").hide();
     }
 });
