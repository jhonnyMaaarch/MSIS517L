/*javascript */
var jsonList = {"ReasonForContact":[{"id":"2","Reason":"Select One"},
   {"id":"3","Reasoon":"Job Offer"},
  {"id":"4","Reason":"Mentoring"},
  {"id":"5","Reason":"Other"}]}

  $(document).ready(function(){
   var ListItems="";
   for (var i=0; i < jsonList.ReasonForContact.length; i++){
     ListItems += "<option value='" + jsonList.ReasonForContact[i].id + "'>" + jsonList.ReasonForContact[i].Reason + "</option>";
   }
    $("#contactDropDown").html(ListItems);
  });
