
var $select = $('#contactDropDown');
$.getJSON('DropDown.json', function(data){
  $select.html('');

  for (var i = 0; i < data['ReasonForContact'].length; i++) {
    $select.append('<option id="' + data['ReasonForContact'][i]['id'] + '">' + data['ReasonForContact'][i]['Reason'] + '</option>');
  }
});
